// Miriam Duran Reyes
// Adquiriendo las destrezas b�sicas

//Importamos bibliotecas
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <Windows.h>
#include <WinSock2.h>
#include <WS2tcpip.h>

#pragma comment(lib, "ws2_32.lib")

// Funci�n para escribir la fecha y hora en producto2.txt. 
void FechaHora() {
// Nombre del archvio que queremos que se esriba hora y fecha 
const char* nombreArchivo = "producto2.txt";

//Almacenar la ruta del ejecutable y directorio y c�mo obtenemos la ruta:
char rutaEjecutable[_MAX_PATH];
char rutaDirectorio[_MAX_PATH];
GetModuleFileName(NULL, rutaDirectorio, rutaEjecutable);

// Ahora queremos eliminar el nombre del ejecutable y de esta forma obtener la ruta del directorio:
char* eliminadoEjectuable = strrchr(rutaEjecutable, '\\');
if (eliminadoEjectuable != NULL) {
    *eliminadoEjectuable = '\0';
}
// Ahora realizamos la construccion del enlace
snprintf(rutaDirectorio, MAX_PATH, "%s\\%s", rutaEjecutable, nombreArchivo);

// Abrimos el archivos en modo adjuntar para agregar el contenido
 FILE* archivo = fopen("producto2.txt", "a");
    if (archivo == NULL) {
        printf("Error al abrir el archivo producto2.txt\n");
        return;
    }
    // Como obtenemos la fecha actual
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    fprintf(archivo, "Fecha y Hora: %04d-%02d-%02d %02d:%02d:%02d\n",
        tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday,
        tm.tm_hour, tm.tm_min, tm.tm_sec);
    fclose(archivo);
    printf("Fecha y hora insertadas en producto2.txt correctamente.\n");
}

// Comprobar el ping a una lista de IPs
void comprobarPing() {
    char rutaArchivo[256];
    printf("Introduce la ruta del archivo con las direcciones IP: ");
    scanf("%s", rutaArchivo);

    FILE* archivoIPs = fopen(rutaArchivo, "r");
    if (archivoIPs == NULL) {
        printf("Error al abrir el archivo %s\n", rutaArchivo);
        return;
    }

    // Utilizamos WINSOCK
    WSADATA wsaData;
    int Resultado = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (Resultado != 0) {
        printf("Ha habido un error al iniciar Winsock: %d\n", Resultado);
        return;
    }

    char Linea[256];
    while (fgets(Linea, 365, archivoIPs)) {
        int eliminarLinea = strlen(Linea);
        if (eliminarLinea > 0 && Linea[eliminarLinea - 1] == '\n') {
            Linea[eliminarLinea - 1] = '0';
        }
        printf("\nWEB: %s -> \n", Linea);

        struct hostent* host;
        host = gethostbyname(Linea);

        if (host == NULL) {
            printf("Ha habido un fallo al recuperar la IP");
            continue;
        }

        char* ip = inet_ntoa(*(struct in_addr*)host->h_addr);

        printf("%s, \n", ip);

        // Mostrar el contenido del archivo
        char ip[256];
        printf("Direcciones IP encontradas:\n");
        while (fgets(ip, sizeof(ip), archivoIPs) != NULL) {
            printf("%s", ip);
        }
        rewind(archivoIPs);

        FILE* archivoSalida = fopen("producto2.txt", "a");
        if (archivoSalida == NULL) {
            printf("Error al abrir el archivo producto2.txt\n");
            fclose(archivoIPs);
            return;
        }

        // Escribir fecha y hora en producto2.txt
        FechaHora();

        // Comprobar ping para cada IP
        printf("\nComprobando respuesta al ping:\n");
        while (fgets(ip, sizeof(ip), archivoIPs) != NULL) {
            // Eliminar salto de l�nea
            ip[strcspn(ip, "\n")] = 0;

            // Ejecutar comando ping
            char comando[300];
            snprintf(comando, sizeof(comando), "ping -c 1 -w 1 %s > /dev/null 2>&1", ip);
            int resultado = system(comando);

            if (resultado == 0) {
                printf("Respuesta positiva: %s\n", ip);
                fprintf(archivoSalida, "Respuesta positiva: %s\n", ip);
            }
            else {
                printf("No responde: %s\n", ip);
            }
        }

        fclose(archivoIPs);
        fclose(archivoSalida);
        printf("Resultados almacenados en producto2.txt.\n");
    }
}

// Mostraremos y guardarremos informaci�n de un adaptador de red
void guardarConfiguracionRed() {
    char adaptador[256];
    printf("Introduce el nombre del adaptador de red: ");
    scanf("%s", adaptador);

    FILE* archivoSalida = fopen("adaptador.txt", "w");
    if (archivoSalida == NULL) {
        printf("Error al crear el archivo adaptador.txt\n");
        return;
    }

    // Ejecutar comando ipconfig
    char comando[300];
#ifdef _WIN32
    snprintf(comando, sizeof(comando), "ipconfig > temp_red.txt");
#else
    snprintf(comando, sizeof(comando), "ifconfig %s > temp_red.txt", adaptador);
#endif

    int resultado = system(comando);
    if (resultado != 0) {
        printf("Error al ejecutar el comando para obtener la configuraci�n de red.\n");
        fclose(archivoSalida);
        return;
    }

    // Filtrar informaci�n relevante
    FILE* archivoTemp = fopen("temp_red.txt", "r");
    if (archivoTemp == NULL) {
        printf("Error al abrir el archivo temporal.\n");
        fclose(archivoSalida);
        return;
    }

    char linea[256];
    fprintf(archivoSalida, "Configuraci�n de red para el adaptador: %s\n", adaptador);
    printf("Configuraci�n de red:\n");
    while (fgets(linea, sizeof(linea), archivoTemp) != NULL) {
        // Filtrar l�neas relevantes para IP, m�scara y puerta de enlace
        if (strstr(linea, "Direcci�n IP") || strstr(linea, "M�scara de subred") || strstr(linea, "Puerta de enlace")) {
            fprintf(archivoSalida, "%s", linea);
            printf("%s", linea);
        }
    }

    fclose(archivoTemp);
    fclose(archivoSalida);
    printf("Configuraci�n de red almacenada en adaptador.txt.\n");

    // Eliminar archivo temporal
    remove("temp_red.txt");
}

// Realizamos nuestro MENU con opciones solicitadas en actividad
int main() {
    int menu;

    do {
        printf("\n~ Menu Principal ~\n");
        printf("1. Insertar fecha y hora en producto2.txt\n");          //Mostras fecha y hora
        printf("2. Comprobar IPs con ping\n");                          // Comprobar IPS
        printf("3. Guardar configuracion de red en adaptador.txt\n");   // Verificar informaci�n de los adaptadores
        printf("4. Salir\n");
        printf("Selecciona una opcion: ");
        scanf("%d", &menu);

        switch (menu) {
        case 1:
            FechaHora();
            break;
        case 2:
            comprobarPing();
            break;
        case 3:
            guardarConfiguracionRed();
            break;
        case 4:
            printf("Saliendo de la aplicacion...\n");
            break;
        default:
            printf("Opcion no valida. Selecciona opcion del 1 al 4.\n");
        }
    } while (menu != 4);

    return 0;
}
